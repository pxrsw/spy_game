package com.example.spy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class HowToPlayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how_to_play);
        Button back_button = findViewById(R.id.back_button);
        back_button.setOnClickListener(v -> {
            Intent back = new Intent(HowToPlayActivity.this,FirstPageActivity.class);
            startActivity(back);
        });
    }
}
