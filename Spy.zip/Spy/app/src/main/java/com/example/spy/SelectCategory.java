package com.example.spy;

import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import javax.security.auth.Subject;

public class SelectCategory extends AppCompatActivity {
    public  static  String subject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_category);

        Intent go_to_player_name = new Intent(this,PlayersNameActivity.class);
        Intent go_to_PlayGame = new Intent(this,PlayGame.class);



        ImageView public_img = findViewById(R.id.public_img_id);
        ImageView pro_img = findViewById(R.id.pro_img_id);
        ImageView countries_img = findViewById(R.id.country_img_id);
        ImageView cities_img = findViewById(R.id.city_img_id);

        public_img.setOnClickListener(v->{
           subject="General";
            startActivity(go_to_player_name);
        });

        pro_img.setOnClickListener(v->{
            subject="Pro";
            startActivity(go_to_player_name);
        });

        countries_img.setOnClickListener(v->{
            subject="Country";
            startActivity(go_to_player_name);
        });

        cities_img.setOnClickListener(v->{
            subject="City";
            startActivity(go_to_player_name);
        });
    }
}
