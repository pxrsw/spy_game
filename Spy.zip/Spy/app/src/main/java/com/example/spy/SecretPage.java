package com.example.spy;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class SecretPage extends AppCompatActivity {
    public static int mode=0;
     public  static Cursor NextPerson_Cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_secret_page);
        TextView whoisnext = findViewById(R.id.whoisnext_textview);
        Button manam_button = findViewById(R.id.Manam_Button);
        DatabaseAccess databaseAccess = new DatabaseAccess(this);
         NextPerson_Cursor = databaseAccess.getDb().rawQuery("SELECT*FROM Names", null);
         if(mode==0) {
             NextPerson_Cursor.moveToFirst();
            mode++;
    }
         NextPerson_Cursor.moveToPosition(PlayGame.chandomi-1);
        String yaroo = NextPerson_Cursor.getString(0);
        whoisnext.setText("نوبت "+yaroo+" است");
        NextPerson_Cursor.moveToNext();
        manam_button.setOnClickListener(v -> {
            Intent gotoseeSubject = new Intent(SecretPage.this,PlayGame.class);
            startActivity(gotoseeSubject);
        });



    }
}
