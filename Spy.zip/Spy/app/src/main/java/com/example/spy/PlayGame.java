package com.example.spy;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Time;
import java.util.Random;
import java.util.Timer;

public class PlayGame extends AppCompatActivity {
    public  static int chandomi=1;
    public static  int NumberofPlayer;
    public  static  int mode =0;
   public static String ExampleOfSubject;
    public  static Cursor Subject_curssor;
   public static int khale;
    public  static  int spy;
    public static Random random;
    int rowcount=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_game);
         String Subject=SelectCategory.subject;


          NumberofPlayer = SelectNumofPlayersActivity.number_of_players;

        TextView Showsubject =findViewById(R.id.showSubject_EditText);
        Button nextperson = findViewById(R.id.gotoSecret_Button);
        DatabaseAccess databaseAccess = new DatabaseAccess(this);
         Subject_curssor =databaseAccess.getDb().rawQuery("SELECT*FROM General",null);

        if (Subject.equals("General")){
             Subject_curssor =databaseAccess.getDb().rawQuery("SELECT*FROM General",null);
        }
        if (Subject.equals("Pro")){
             Subject_curssor =databaseAccess.getDb().rawQuery("SELECT*FROM Pro",null);
        }
        if (Subject.equals("City")){
             Subject_curssor =databaseAccess.getDb().rawQuery("SELECT*FROM City",null);
        }
        if (Subject.equals("Country")){
             Subject_curssor =databaseAccess.getDb().rawQuery("SELECT*FROM Country",null);
        }
        Subject_curssor.moveToFirst();
        while(!Subject_curssor.isAfterLast()){
            rowcount++;
            Subject_curssor.moveToNext();
        }
        Subject_curssor.moveToFirst();

        if (mode==0){
            Random random2 = new Random();
            khale =random2.nextInt(rowcount-1)+1;
            mode=10;
            Subject_curssor.moveToPosition(khale);
            System.out.println(rowcount);
            System.out.println(khale);
            ExampleOfSubject=Subject_curssor.getString(0);
            random= new Random();
            spy=random.nextInt(NumberofPlayer)+1;


        }
        if (chandomi!=spy){
            Showsubject.setText(ExampleOfSubject);
        }else{
            Showsubject.setText("SPY");
        }
        chandomi++;
        if (chandomi>NumberofPlayer+1){
            Intent gotoTimer = new Intent(PlayGame.this, Timer_Activity.class);
            startActivity(gotoTimer);
        }
        nextperson.setOnClickListener(v -> {
            if (chandomi>NumberofPlayer){
                chandomi=1;
                mode=0;
                SecretPage.mode=0;
                Intent gototimer = new Intent(PlayGame.this, Timer_Activity.class);
                startActivity(gototimer);

            }else {
                Intent gotosecretpage_Cursor = new Intent(PlayGame.this, SecretPage.class);
                startActivity(gotosecretpage_Cursor);

            }
        });


        // vaghti be nafare random residim bayad spy set shavad











    }
}
