package com.example.spy;

import android.content.ContentValues;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SelectCaetegoryOfNew extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_caetegory_of_new);
        RadioGroup newword_rg = findViewById(R.id.CategoryOfNew_RadioGp);
        RadioButton Genereal_radiob = findViewById(R.id.General_RadioB);
        RadioButton pro_radiob = findViewById(R.id.Pro_RadioB);
        RadioButton Country_radiob = findViewById(R.id.Country_RadioB);
        RadioButton City_radiob = findViewById(R.id.City_RadioB);
        Button add_button = findViewById(R.id.Add_Button);
        EditText wordname= findViewById(R.id.Word_Edittext);
        DatabaseAccess databaseAccess = new DatabaseAccess(this);

        add_button.setOnClickListener(v -> {
            int selectedID=newword_rg.getCheckedRadioButtonId();
            if (selectedID==Genereal_radiob.getId()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Subject",wordname.getText().toString());
                databaseAccess.getDb().insert("General",null,contentValues);
            }


            if (selectedID==pro_radiob.getId()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Subject",wordname.getText().toString());
                databaseAccess.getDb().insert("Pro",null,contentValues);
            }


            if (selectedID==Country_radiob.getId()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Subject",wordname.getText().toString());
                databaseAccess.getDb().insert("Country",null,contentValues);

            }


            if (selectedID==City_radiob.getId()){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Subject",wordname.getText().toString());
                databaseAccess.getDb().insert("City",null,contentValues);

            }
            wordname.setText("");
            Toast.makeText(getApplicationContext(),"با موفقیت اضافه شد",Toast.LENGTH_LONG).show();



        });
    }
}
