package com.example.spy;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class PlayersNameActivity extends AppCompatActivity {
   // int max=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players_name);


        ImageView play_game = findViewById(R.id.start_game_img_id);

        EditText player1_name = findViewById(R.id.player1_name_txt_id);
        EditText player2_name = findViewById(R.id.player2_name_txt_id);
        EditText player3_name = findViewById(R.id.player3_name_txt_id);
        EditText player4_name = findViewById(R.id.player4_name_txt_id);
        EditText player5_name = findViewById(R.id.player5_name_txt_id);
        EditText player6_name = findViewById(R.id.player6_name_txt_id);
        EditText player7_name = findViewById(R.id.player7_name_txt_id);
        EditText player8_name = findViewById(R.id.player8_name_txt_id);
        EditText player9_name = findViewById(R.id.player9_name_txt_id);
        EditText player10_name = findViewById(R.id.player10_name_txt_id);
        EditText player11_name = findViewById(R.id.player11_name_txt_id);
        EditText player12_name = findViewById(R.id.player12_name_txt_id);
        EditText player13_name = findViewById(R.id.player13_name_txt_id);
        EditText player14_name = findViewById(R.id.player14_name_txt_id);
        DatabaseAccess databaseAccess = new DatabaseAccess(this);
        Cursor Names_Cursor =databaseAccess.getDb().rawQuery("SELECT*FROM Names",null);
        System.out.println(databaseAccess.getDb().getMaximumSize());
        Names_Cursor.moveToFirst();

      //  max=Integer.valueOf(getIntent().getStringExtra("Number2"));

        databaseAccess.db.delete("Names",null,null);
        if (SelectNumofPlayersActivity.number_of_players>=5)

            player5_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=6)

            player6_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=7)

            player7_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=8)

            player8_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=9)

            player9_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=10)

            player10_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=11)

            player11_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=12)

            player12_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=13)

            player13_name.setVisibility(View.VISIBLE);
        if (SelectNumofPlayersActivity.number_of_players>=14)
            player14_name.setVisibility(View.VISIBLE);

      //  System.out.println(max);


        play_game.setOnClickListener(v->{

          if(player1_name.getText()!=null){
              Log.d("mylog","Hi textbox 1");
              ContentValues contentValues = new ContentValues();
              contentValues.put("Name",player1_name.getText().toString());
              databaseAccess.getDb().insert("Names",null,contentValues);
          }
            if(player2_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player2_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player3_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player3_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player4_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player4_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player5_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player5_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player6_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player6_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player7_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player7_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player8_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player8_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player9_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player9_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player10_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player10_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player11_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player11_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player12_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player12_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player13_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player13_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            if(player14_name.getText()!=null){
                ContentValues contentValues = new ContentValues();
                contentValues.put("Name",player14_name.getText().toString());
                databaseAccess.getDb().insert("Names",null,contentValues);
            }
            Intent go_to_PlayGame = new Intent(PlayersNameActivity.this,SecretPage.class);
           // System.out.println(max);
            //go_to_PlayGame.putExtra("Number",max);
            startActivity(go_to_PlayGame);
        });
    }
}
