package com.example.spy;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DatabaseAccess extends SQLiteAssetHelper {

    private static String DATABASE_NAME= "mydb.db";
    private  static int DATABASE_Version = 1;
    SQLiteDatabase db;
    public DatabaseAccess(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_Version);
        db=getWritableDatabase();
    }
    public  SQLiteDatabase getDb () {
        return  db;
    }

}
