package com.example.spy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class FirstPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_page);

        Button go_to_select_num_of_players = findViewById(R.id.go_to_select_players_btn_id);
        Button how_to_play = findViewById(R.id.how_to_play_btn_id);
        Button goto_addnew= findViewById(R.id.add_button);

        go_to_select_num_of_players.setOnClickListener(v->{
            Intent go_to_selectplayers_intent = new Intent(this, SelectNumofPlayersActivity.class);
            startActivity(go_to_selectplayers_intent);
        });

        how_to_play.setOnClickListener(v -> {
            Intent go_howtoplay_intent = new Intent(this,HowToPlayActivity.class);
            startActivity(go_howtoplay_intent);
        });
        goto_addnew.setOnClickListener(v -> {
            Intent gotoaddnew_Intent = new Intent(FirstPageActivity.this,SelectCaetegoryOfNew.class);
            startActivity(gotoaddnew_Intent);
        });
    }

}
