package com.example.spy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class SelectNumofPlayersActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String text;

    public static int number_of_players;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_players);



        Spinner spinner_numbers = findViewById(R.id.spinner1_id);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.numbers,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_numbers.setAdapter(adapter);
        spinner_numbers.setOnItemSelectedListener(this);


        Button go_to_players_name = findViewById(R.id.go_to_players_name_btn_id);

        go_to_players_name.setOnClickListener(v->{
            Intent go_cat_intent = new Intent(this,SelectCategory.class);

            startActivity(go_cat_intent);
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
         text = parent.getItemAtPosition(position).toString();

        System.out.println("dar num hastim :   "+text);
        number_of_players = Integer.parseInt(text);
        Toast.makeText(parent.getContext(),text,Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


}
