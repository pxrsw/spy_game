package com.example.spy;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Timer_Activity extends AppCompatActivity {
    Button ok_button;
    Button ridim_button;
    TextView Timer_textview;
    CountDownTimer countDownTimer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_);
         ok_button = findViewById(R.id.ok_button);
        ridim_button = findViewById(R.id.ridim_button);
         Timer_textview = findViewById(R.id.Timer_textview);
         // boro berim too kare timer
         countDownTimer = new CountDownTimer(300 * 1000, 1000) {

            public void onTick(long millisUntilFinished) {
                Timer_textview.setText((millisUntilFinished / 60000) +":"+((int) ((millisUntilFinished)-(millisUntilFinished / 60000)*60000)/1000)+ " دیگه مونده، بدوو");


            }

            public void onFinish() {
                Timer_textview.setText("پس چی شددد :(");
            }
        };
         countDownTimer.start();
        ok_button.setOnClickListener(v -> {
            Toast.makeText(getApplicationContext(),"هورااا ، بریم سر دست بعدی",Toast.LENGTH_LONG).show();
            khelas ();
        });
        ridim_button.setOnClickListener(v -> {
            khelas();
            Toast.makeText(getApplicationContext(),"اخخخ ، طوری نیست ، بعدا جبران کن",Toast.LENGTH_LONG).show();
        });
    }

    private void khelas() {
        countDownTimer.cancel();
        Intent azavalbazikon = new Intent(Timer_Activity.this,SecretPage.class);
        startActivity(azavalbazikon);
    }
}
